# ALCATRAZ

Alcatraz is an open source roblox script for the game phantom forces. It includes fully functional instant reload, fast equip, aimbot, silent aim, FOV, and other character mods. There are previews below.

![MAIN](https://raw.githubusercontent.com/P-DennyGamingYT/ALCATRAZ-PF/main/images/m.PNG)
![PLAYER MODS](https://raw.githubusercontent.com/P-DennyGamingYT/ALCATRAZ-PF/main/images/pm.PNG)

# Usage

To use Alcatraz, copy the code below and paste it into your exploit. After you may execute. NOTE: AVERAGE LOADING TIMES BELOW.

Script: ```loadstring(game:HttpGet("https://raw.githubusercontent.com/P-DennyGamingYT/ALCATRAZ-PF/main/loader.lua"))()```

LOAD TIMES:

```25-50mb/s - 15-30sec.```
```50-100mb/s - 5-10sec.```
```150mb/s - 5sec.```

IF SCRIPT DOESN'T LOAD IMMEDIATELY JUST WAIT FOR IT TO LOAD.

# Credits

Made By [Payson Holmes](https://github.com/P-DennyGamingYT/)

&copy; 2022 - PDennSploit Softworks LLC
